<template>
  <router-link to="/index" class="logo-wrapper ">
    <svg-icon icon="logo" class="verticalMiddle" :size="30" />
    <div class="logo-title verticalMiddle">Vue Antd Admin</div>
  </router-link>
</template>

<script>
export default {
  name: 'logo',
  data() {
    return {};
  }
};
</script>
