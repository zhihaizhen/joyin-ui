export { default as sideBar } from './sideBar/index.vue';
export { default as navBar } from './navBar/index.vue';
export { default as tagView } from './tagView/index.vue';
export { default as setting } from './setting/index.vue';
export { default as horizontalSide } from './sideBar/horizontalSide.vue';
