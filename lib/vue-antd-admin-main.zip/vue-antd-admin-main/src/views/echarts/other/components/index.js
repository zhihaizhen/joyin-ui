export { default as liquidChart } from './liquidChart.vue';
export { default as gaugeChart } from './gaugeChart.vue';
export { default as radarChart } from './radarChart.vue';
export { default as treeChart } from './treeChart.vue';
export { default as wordChart } from './wordChart.vue';
