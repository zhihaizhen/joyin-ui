import articlePage from './articlePage/index.vue';
import dynamicPage from './dynamicPage/index.vue';
import noticePage from './noticePage/index.vue';

export { articlePage, dynamicPage, noticePage };
