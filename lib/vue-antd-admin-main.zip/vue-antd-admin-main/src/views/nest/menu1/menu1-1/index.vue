<template>
  <div>
    <p style="padding-left:15px">嵌套菜单1-1</p>
    <a-tag style="margin-left:15px" color="#87d068">
      嵌套菜单1-1
    </a-tag>
  </div>
</template>

<script>
export default {
  name: 'menu1-1',
  data() {
    return {};
  }
};
</script>
