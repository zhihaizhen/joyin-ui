<template>
  <div>
    <p style="padding-left:30px">嵌套菜单1-2-1</p>
    <a-tag style="margin-left:30px" color="skyblue">
      嵌套菜单1-2-1
    </a-tag>
  </div>
</template>

<script>
export default {
  name: 'menu1-2-1',
  data() {
    return {};
  }
};
</script>
