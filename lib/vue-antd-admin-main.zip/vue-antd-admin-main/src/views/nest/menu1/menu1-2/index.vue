<template>
  <div>
    <p style="padding-left:15px">嵌套菜单1-2</p>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'menu1-2',
  data() {
    return {};
  }
};
</script>
