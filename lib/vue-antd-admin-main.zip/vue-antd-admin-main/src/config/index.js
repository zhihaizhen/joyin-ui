import Constant from './constant';

export default {
  install(Vue) {
    Vue.use(Constant);
  }
};
