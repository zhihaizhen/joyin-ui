const toolbar = [
  'undo redo  bold italic underline strikethrough   alignleft aligncenter alignright   blockquote  formatselect fontsizeselect ',
  'forecolor backcolor searchreplace bullist numlist outdent indent link image  media  charmap      table  preview  fullscreen code'
];
export default toolbar;
