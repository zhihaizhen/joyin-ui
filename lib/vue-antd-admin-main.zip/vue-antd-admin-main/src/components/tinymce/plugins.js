const plugins = [
  'advlist anchor autolink autosave code colorpicker  contextmenu directionality  fullscreen hr image imagetools  link lists media nonbreaking noneditable pagebreak paste preview print save searchreplace spellchecker tabfocus table template textcolor textpattern visualblocks visualchars wordcount'
];

export default plugins;
