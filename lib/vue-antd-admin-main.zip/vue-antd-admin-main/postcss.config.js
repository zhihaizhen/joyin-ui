module.exports = {
  plugins: [require('autoprefixer')] // 引用该插件即可了
};
